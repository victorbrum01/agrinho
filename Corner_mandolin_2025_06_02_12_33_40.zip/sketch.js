let carro;
let obstaculos = [];
let estradaLargura;

function setup() {
  createCanvas(400, 600);
  estradaLargura = width;
  carro = new Carro();
}

function draw() {
  background(50);

  // Estrada
  fill(100);
  rect(0, 0, estradaLargura, height);

  // Linha tracejada do meio
  stroke(255);
  strokeWeight(2);
  for (let i = 0; i < height; i += 40) {
    line(width / 2, i, width / 2, i + 20);
  }

  carro.mostrar();
  carro.mover();

  if (frameCount % 60 == 0) {
    obstaculos.push(new Obstaculo());
  }

  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].mover();
    obstaculos[i].mostrar();

    if (obstaculos[i].colidiu(carro)) {
      noLoop(); // Fim de jogo
      textSize(48);
      fill(255, 0, 0);
      textAlign(CENTER, CENTER);
      text("Game Over", width / 2, height / 2);
    }

    if (obstaculos[i].y > height) {
      obstaculos.splice(i, 1);
    }
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    carro.dir = -1;
  } else if (keyCode === RIGHT_ARROW) {
    carro.dir = 1;
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    carro.dir = 0;
  }
}

class Carro {
  constructor() {
    this.largura = 40;
    this.altura = 60;
    this.x = width / 2 - this.largura / 2;
    this.y = height - this.altura - 10;
    this.dir = 0;
    this.vel = 5;
  }

  mostrar() {
    fill(0, 0, 255);
    rect(this.x, this.y, this.largura, this.altura);
  }

  mover() {
    this.x += this.dir * this.vel;
    this.x = constrain(this.x, 0, width - this.largura);
  }
}

class Obstaculo {
  constructor() {
    this.largura = 40;
    this.altura = 40;
    this.x = random(0, width - this.largura);
    this.y = -this.altura;
    this.vel = 5;
  }

  mostrar() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.largura, this.altura);
  }

  mover() {
    this.y += this.vel;
  }

  colidiu(carro) {
    return (
      this.x < carro.x + carro.largura &&
      this.x + this.largura > carro.x &&
      this.y < carro.y + carro.altura &&
      this.y + this.altura > carro.y
    );
  }
}
